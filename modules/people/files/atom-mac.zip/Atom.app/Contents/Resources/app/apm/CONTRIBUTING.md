See the [Atom contributing guide](https://github.com/atom/atom/blob/master/CONTRIBUTING.md)
